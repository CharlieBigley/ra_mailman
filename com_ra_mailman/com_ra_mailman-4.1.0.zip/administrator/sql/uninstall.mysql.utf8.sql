# 7 files in total
# 31/05/23 created
# 09/06/23 mail_access
DROP TABLE IF EXISTS `#__ra_mail_access`;
DROP TABLE IF EXISTS `#__ra_mail_lists`;
DROP TABLE IF EXISTS `#__ra_mail_methods`;
DROP TABLE IF EXISTS `#__ra_mail_recipients`;
DROP TABLE IF EXISTS `#__ra_mail_shots`;
DROP TABLE IF EXISTS `#__ra_mail_subscriptions`;
DROP TABLE IF EXISTS `#__ra_mail_subscriptions_audit`;
# Logfile may be required for other components

