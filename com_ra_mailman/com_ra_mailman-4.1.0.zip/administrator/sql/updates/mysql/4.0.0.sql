ALTER `#__ra_mail_shots` CHANGE `date_sent` `date_sent` DATETIME NULL DEFAULT NULL; 
ALTER `#__ra_mail_shots` CHANGE `processing_started` `processing_started` DATETIME NULL DEFAULT NULL; 